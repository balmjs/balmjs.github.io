# BalmJS [Getting Started](https://balm.js.org/docs/guide/getting-started.html)

1. `unzip balm-example.zip -d balm-example`
2. `cd /path/to/balm-example`
3. `yarn` or `npm i`
4. `yarn run dev` or `npm run dev`

Enjoy!

thx [BalmJS](https://balm.js.org/)

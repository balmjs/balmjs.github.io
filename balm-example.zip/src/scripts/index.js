document.getElementById('app').innerHTML = '<h1>Hello BalmJS</h1>';
